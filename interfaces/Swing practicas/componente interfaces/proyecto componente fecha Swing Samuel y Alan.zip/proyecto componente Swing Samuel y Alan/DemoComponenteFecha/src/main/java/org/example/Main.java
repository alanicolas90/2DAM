package org.example;

import io.vavr.control.Either;
import org.example.exceptions.FechaException;
import org.example.exceptions.FechaImposibleException;
import org.example.exceptions.FechaIncompletaException;
import org.example.exceptions.FechaIncorrectaException;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Main extends JFrame {
    private final ComponenteFechaClase componenteFechaInicio;
    private final ComponenteFechaClase componenteFechaFin;

    public Main() {
        componenteFechaInicio = new ComponenteFechaClase();
        componenteFechaFin = new ComponenteFechaClase();

        setLayout(new FlowLayout());
        add(new JLabel("Inicio"));
        add(componenteFechaInicio);
        add(new JLabel("Fin"));
        add(componenteFechaFin);
        setResizable(false);

        JButton comprobar = new JButton("Comprobar");
        add(comprobar);
        comprobar.addActionListener(
                e -> {
                    if (comprobarFecha(componenteFechaInicio).isLeft()) {
                        JOptionPane.showMessageDialog(null,"Error en la Fecha de inicio: " + comprobarFecha(componenteFechaInicio).getLeft() );
                    } else if (comprobarFecha(componenteFechaFin).isLeft()) {
                        JOptionPane.showMessageDialog(null, "Error en la Fecha de fin: " + comprobarFecha(componenteFechaFin).getLeft() );
                    } else {
                        LocalDate fechaInicio = comprobarFecha(componenteFechaInicio).get();
                        LocalDate fechaFin = comprobarFecha(componenteFechaFin).get();
                        if (fechaInicio.isAfter(fechaFin)) {
                            JOptionPane.showMessageDialog(null, "Orden incorrecto");
                        } else {
                            //pasar fechas a dias y calcular diferencia
                            long diferenciaDias = ChronoUnit.DAYS.between(fechaInicio, fechaFin);
                            JOptionPane.showMessageDialog(null, "Diferencia en dias: " + diferenciaDias);

                        }
                    }
                }
        );
    }

    private Either<String, LocalDate> comprobarFecha(ComponenteFechaClase date) {
        try {
            LocalDate fecha = date.getDate();
            return Either.right(fecha);
        } catch (FechaIncompletaException | FechaImposibleException | FechaIncorrectaException ex) {
            return Either.left(ex.getMessage());
        } catch(NumberFormatException ex){
            return Either.left("Has introducido un caracter no valido en el año");
        }
        catch (FechaException ex) {
            return Either.left("Otro error");
        }
    }


    public static void main(String[] args) {
        JFrame frame = new Main();
        frame.setTitle("Demo Componente Fecha");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

