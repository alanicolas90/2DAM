package org.example.exceptions;

public class FechaException extends Exception{
    public FechaException(String message) {
        super(message);
    }
}
