package org.example;

import org.example.exceptions.FechaException;
import java.time.LocalDate;

public interface ComponenteFecha {
    LocalDate getDate() throws FechaException;
    void setDate(int day, int month, int year);
}
