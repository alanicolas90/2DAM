package org.example.exceptions;

public class FechaImposibleException extends FechaException {
    public FechaImposibleException(String message) {
        super(message);
    }
}
