package org.example.exceptions;

public class FechaIncorrectaException extends FechaException {
    public FechaIncorrectaException(String message) {
        super(message);
    }
}
