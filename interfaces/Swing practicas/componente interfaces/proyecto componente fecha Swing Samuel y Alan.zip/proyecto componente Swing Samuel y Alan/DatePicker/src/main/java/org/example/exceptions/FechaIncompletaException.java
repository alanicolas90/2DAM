package org.example.exceptions;

public class FechaIncompletaException extends FechaException {
    public FechaIncompletaException(String message) {
        super(message);
    }
}
