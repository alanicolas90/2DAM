package org.example;

import org.example.exceptions.FechaException;
import org.example.exceptions.FechaImposibleException;
import org.example.exceptions.FechaIncompletaException;
import org.example.exceptions.FechaIncorrectaException;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.time.LocalDate;

public class ComponenteFechaClase extends JPanel implements ComponenteFecha {
    private LocalDate localDate;
    private JComboBox<Integer> comboBoxDay;
    private JComboBox<Integer> comboBoxMonth;
    private TextField textFieldYear;

    public ComponenteFechaClase() {

        comboBoxDay = new JComboBox<>();
        for (int i = 1; i <= 31; i++) {
            comboBoxDay.addItem(i);
        }

        comboBoxMonth = new JComboBox<>();
        for (int i = 1; i <= 12; i++) {
            comboBoxMonth.addItem(i);
        }

        textFieldYear = new TextField("",4);

        Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
        this.setBorder(border);
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));

        this.add(comboBoxDay);
        this.add(comboBoxMonth);
        this.add(textFieldYear);
    }

    @Override
    public LocalDate getDate() throws FechaException {
            int day = (int) comboBoxDay.getSelectedItem();
            int month = (int) comboBoxMonth.getSelectedItem();


        if (textFieldYear.getText().isEmpty()) {
            throw new FechaIncompletaException("No has introducido ningún año");
        }
        int year = Integer.parseInt(textFieldYear.getText());

        if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
            throw new FechaIncorrectaException("El mes " + month + " no puede tener más de 30 días.");
        }

        if (month == 2) {
            boolean esBisiesto = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);

            if (day > 29) {
                throw new FechaIncorrectaException("Febrero no puede tener más de 30 días");
            }

            if (day == 29 && !esBisiesto) {
                throw new FechaImposibleException("Febrero del año " + year + " no puede tener más de 29 días.");
            }
        }

        localDate = LocalDate.of(year, month, day);
        return localDate;
    }

    @Override
    public void setDate(int day, int month, int year) {
        comboBoxDay.setSelectedItem(day);
        comboBoxMonth.setSelectedItem(month);
        textFieldYear.setText(String.valueOf(year));
    }
}
