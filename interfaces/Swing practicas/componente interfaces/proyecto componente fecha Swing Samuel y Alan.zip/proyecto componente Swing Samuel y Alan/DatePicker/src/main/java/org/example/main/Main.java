package org.example.main;

import org.example.ComponenteFecha;
import org.example.ComponenteFechaClase;

import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }

    public Main() {
        setTitle("Componente Fecha");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(200, 100);
        setLocationRelativeTo(null);

        ComponenteFecha componenteFecha = new ComponenteFechaClase();
        add((Component) componenteFecha);

        setVisible(true);
    }
}
