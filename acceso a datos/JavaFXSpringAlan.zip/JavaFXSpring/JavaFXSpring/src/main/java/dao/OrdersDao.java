package dao;

import io.vavr.control.Either;
import model.ErrorC;
import model.Order;

import java.util.List;

public interface OrdersDao {

    Either<ErrorC, List<Order>> getAll();

    Either<ErrorC, List<Order>> get(int idUserLogged);

    Either<ErrorC, Integer> save(Order order);

    Either<ErrorC, Integer> update(Order order);

    Either<ErrorC, Integer> delete(int id, boolean delete);

}
