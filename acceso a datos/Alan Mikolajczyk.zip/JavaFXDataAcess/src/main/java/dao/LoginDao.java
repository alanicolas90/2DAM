package dao;

public interface LoginDao {
    boolean login(String username, String password);
}
