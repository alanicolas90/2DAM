package model;

import lombok.Data;

@Data
public class Table {
    int id;
    int seats;
}
