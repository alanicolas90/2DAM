package com.example.ejerciciodatajsonlocal.ui.pantallas.detail


data class DetailState(
    val message:String? = null
)
