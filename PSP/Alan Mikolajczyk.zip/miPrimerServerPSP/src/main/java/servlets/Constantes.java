package servlets;

public class Constantes {

    public static final String FELICIDADES_HAS_ADIVINADO_EL_NUMERO = "FELICIDADES HAS ADIVINADO EL NUMERO";
    public static final String COLOR_AMARILLO = "#FFFF00";
    public static final String NO_HAS_ADIVINADO_EL_NUMERO = "no has adivinado el numero";
    public static final String COLOR_ROJO = "#b01e3a";
    public static final String NUMERO_VACIO_PORFAVOR_ESCRIBA_UN_NUMERO = "numero vacio, porfavor escriba un numero";
    public static final String ESCRIBE_UN_NUMERO = "Escribe un numero";
    public static final String NUMERO_NO_VALIDO = "numero no valido";
    public static final String COLOR_AZUL = "#2236e1";
    public static final String ES_UN_STRING = ".*\\D.*";

    private Constantes() {
    }
}
