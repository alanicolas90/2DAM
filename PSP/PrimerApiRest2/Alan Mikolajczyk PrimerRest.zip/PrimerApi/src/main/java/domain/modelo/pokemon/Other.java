package domain.modelo.pokemon;

public class Other{
	private DreamWorld dreamWorld;
	private Home home;
}
