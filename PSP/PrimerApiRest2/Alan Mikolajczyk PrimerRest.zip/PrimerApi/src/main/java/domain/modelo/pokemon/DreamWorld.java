package domain.modelo.pokemon;

public class DreamWorld{
	private String frontDefault;
	private Object frontFemale;
}
