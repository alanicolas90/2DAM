package domain.modelo.berry;

import lombok.Getter;

import java.util.List;

@Getter
public class BerriesResponse {
	private List<ResultsItem> results;

}