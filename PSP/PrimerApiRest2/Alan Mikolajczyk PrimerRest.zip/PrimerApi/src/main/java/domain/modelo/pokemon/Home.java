package domain.modelo.pokemon;

public class Home{
	private Object frontShinyFemale;
	private String frontDefault;
	private Object frontFemale;
	private String frontShiny;
}
