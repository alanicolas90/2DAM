package domain.modelo.pokemon;

import lombok.Getter;

@Getter
public class Stat{
	private String name;
	private String url;
}
