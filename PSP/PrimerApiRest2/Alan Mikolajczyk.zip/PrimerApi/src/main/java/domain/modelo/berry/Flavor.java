package domain.modelo.berry;

import lombok.Getter;

@Getter
public class Flavor{
	private String name;
}
