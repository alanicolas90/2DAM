package domain.modelo.berry;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ResultsItem{
	private String name;
	private String url;
}
