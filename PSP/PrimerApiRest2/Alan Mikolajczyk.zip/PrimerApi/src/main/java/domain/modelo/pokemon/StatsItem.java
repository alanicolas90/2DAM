package domain.modelo.pokemon;

import lombok.Getter;

@Getter
public class StatsItem{
	private Stat stat;
	private int base_stat;
	private int effort;



}
