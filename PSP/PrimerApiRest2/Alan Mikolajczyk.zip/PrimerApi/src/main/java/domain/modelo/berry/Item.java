package domain.modelo.berry;

public class Item{
	private String name;
	private String url;
}
