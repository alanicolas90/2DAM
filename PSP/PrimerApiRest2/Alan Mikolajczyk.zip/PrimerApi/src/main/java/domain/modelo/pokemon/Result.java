package domain.modelo.pokemon;


import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public class Result {
    String name;
    String url;
}
