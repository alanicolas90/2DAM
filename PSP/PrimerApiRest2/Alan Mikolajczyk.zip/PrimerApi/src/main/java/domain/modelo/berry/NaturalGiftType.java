package domain.modelo.berry;

public class NaturalGiftType{
	private String name;
	private String url;
}
