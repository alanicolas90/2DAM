package domain.modelo.berry;

import lombok.Getter;

@Getter
public class FlavorsItem{
	private Flavor flavor;
	private int potency;
}
