package ui.screens.common;

public class ConstantScreen {


    public static final String FXML_TABLA_POKEMON = "/fxml/tablaPokemon.fxml";
    public static final String FXML_TABLA_BERRIES = "/fxml/tablaBerries.fxml";


    private ConstantScreen() {
    }
}
