package jakarta.rest;

public class ConstantesJakarta {
    public static final String ID = "id";

    private ConstantesJakarta() {
    }
}
